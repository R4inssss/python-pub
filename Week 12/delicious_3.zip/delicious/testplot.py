from scipy.stats import norm
from matplotlib import pyplot as plt
import math


x = [3, 6, 12, 18, 24]
y = [60, 95, 140, 170, 185]

plt.plot(x, y)
plt.xlabel('x - months')
plt.ylabel('y - kg')

plt.title('Problem 13')
plt.show()



